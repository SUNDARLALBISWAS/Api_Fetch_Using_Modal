import logo from './logo.svg';
import './App.css';
import Routingpage from './Routing/Routingpage';

function App() {
  return (
    <div className="App">
      <Routingpage/>
    </div>
  );
}

export default App;
