export const base_url = "https://api.coincap.io";

export const end_url = {
    category: "/v2/assets",
    categorywise: `/v2/assets/`
};
